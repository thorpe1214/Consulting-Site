// app/twitter-image.tsx
export { size, contentType } from "./opengraph-image";
export { default } from "./opengraph-image";

