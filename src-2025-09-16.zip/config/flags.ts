// config/flags.ts
export const flags = {
  email: {
    // Flip to true once RESEND + emails are configured.
    useResend: false,
  },
};

