export default {
  darkMode: "class",
} as const;

